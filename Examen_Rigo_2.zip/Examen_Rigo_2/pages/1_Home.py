import streamlit as st

st.title("🏠 Home")

st.markdown("""
### Bienvenido al Dashboard de Proyectos
Usa el menú lateral para ir a:
Análisis de Proyectos o si quieres ver las visualizaciones generales.
""")
